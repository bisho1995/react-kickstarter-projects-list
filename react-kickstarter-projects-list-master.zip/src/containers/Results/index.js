import Result from "./Results";
export default Result;
