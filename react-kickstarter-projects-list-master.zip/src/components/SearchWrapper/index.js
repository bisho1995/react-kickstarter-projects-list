import SearchWrapper from "./SearchWrapper";
export default SearchWrapper;
