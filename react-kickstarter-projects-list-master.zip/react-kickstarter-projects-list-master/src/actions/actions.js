import { createActions } from "redux-actions";
const { setData, setSearch, showModal } = createActions({
  SET_DATA: data => data,
  SET_SEARCH: search => search,
  SHOW_MODAL: show => show
});
export { setData, setSearch, showModal };
export default null;
