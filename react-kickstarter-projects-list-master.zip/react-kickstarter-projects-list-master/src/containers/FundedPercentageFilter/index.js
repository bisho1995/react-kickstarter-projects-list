import FundedPercentageFilter from "./FundedPercentageFilter";
export default FundedPercentageFilter;
