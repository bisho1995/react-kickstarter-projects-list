import React, { Component } from "react";
import { connect } from "react-redux";
import "./ModelContainer.scss";
import ModalWrapper from "../../components/ModalWrapper";

class ModelContainer extends Component {
  render() {
    return <ModalWrapper />;
  }
}

const mapStateToProps = state => {
  return state;
};
const dispatchActionsToProps = () => {};

export default connect(
  mapStateToProps,
  null
)(ModelContainer);
