import { handleActions } from "redux-actions";
import { setData, setSearch, showModal } from "../actions";
const initialState = {
  data: [],
  search: "",
  showModal: false
};

const reducer = handleActions(
  {
    [setSearch]: (state, { payload: search }) => {
      return { ...state, search };
    },
    [setData]: (state, { payload: data }) => {
      return { ...state, data };
    },
    [showModal]: (state, { payload: show }) => {
      return { ...state, showModal: show };
    }
  },
  initialState
);

export default reducer;
