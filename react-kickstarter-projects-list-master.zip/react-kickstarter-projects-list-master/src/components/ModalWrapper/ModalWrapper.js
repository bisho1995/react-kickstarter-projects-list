import React from "react";
import "./ModalWrapper.scss";

function ModalWrapper(props) {
  return <div className="modalWrapper">Modal Wrapper</div>;
}

export default ModalWrapper;
